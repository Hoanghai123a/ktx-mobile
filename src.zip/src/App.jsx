import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Search,
  FileUp,
  Shield,
  Home,
  BarChart3,
  UserRound,
  Users,
  LogIn,
  LogOut,
  Building2,
} from "lucide-react";
import { supabase } from "./services/supabaseClient";
// UI (App.jsx thường chỉ còn 2 cái này)
import Confirm from "./components/ui/Confirm";
import TabButton from "./components/ui/TabButton";

// Features
import LoginModal from "./features/auth/LoginModal";
import DeleteGuardModal from "./features/settings/DeleteGuardModal";
import SettingsModal from "./features/settings/SettingsModal";

import KtxView from "./features/ktx/KtxView";
import RoomModal from "./features/ktx/RoomModal";
import WorkerModal from "./features/ktx/WorkerModal";
import AddFloorModal from "./features/ktx/AddFloorModal";
import AddRoomModal from "./features/ktx/AddRoomModal";
import ImportExcelModal from "./features/ktx/ImportExcelModal";
import InitKtxModal from "./features/ktx/InitKtxModal";

import WorkersView from "./features/workers/WorkersView";
import AddWorkerModal from "./features/workers/AddWorkerModal";
import StatsView from "./features/stats/StatsView";
import RecruiterModal from "./features/stats/RecruiterModal";
import AboutView from "./features/about/AboutView";

// Services
import {
  loadSettingsFromDb,
  saveSettingsToDb,
} from "./services/settingsService";

import {
  loadAllFromDb as loadAllFromDbSvc,
  initKtxFromInputs as initKtxSvc,
  wipeDatabase,
} from "./services/ktxDbService";
import {
  addFloor as addFloorSvc,
  deleteFloor as deleteFloorSvc,
  addRoom as addRoomSvc,
  updateRoomCode as updateRoomCodeSvc,
  deleteRoom as deleteRoomSvc,
  checkInWorker as checkInWorkerSvc,
  checkOutStay as checkOutStaySvc,
  transferWorker as transferWorkerSvc,
} from "./services/ktxMutationsService";

import {
  addWorker as addWorkerSvc,
  updateWorker as updateWorkerSvc,
  deleteWorker as deleteWorkerSvc,
} from "./services/workersService";
import { importExcelFileToDb } from "./services/excelImportService";
import { exportExcel as exportExcelSvc } from "./services/excelExportService";
import Pill from "./components/ui/Pill";
// ---------------------------
// Data model
// ---------------------------
// NLĐ = Worker
// Room stays store check-in/out.

function todayISO() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}
// ---------------------------
// Main App
// ---------------------------
export default function App() {
  const DEFAULT_SETTINGS = useMemo(
    () => ({
      siteName: "KTX",
      roomGridCols: 3,
      adminPassword: "123456",
      canDeleteStructure: false, // bật/tắt xóa tầng/phòng
      requirePasswordOnDelete: true, // bắt nhập mật khẩu trước khi xóa

      about: {
        companyName: "Ký túc xá",
        address: "",
        hotline: "0343.751.753",
        email: "",
        website: "",
        mapUrl: "",
        workingHours: "",
        services: [],
        rules: "",
        bankInfo: "",
        description: "",
        adminNotice: "",
      },
    }),
    [],
  );
  const [state, setState] = useState(() => ({
    floors: [],
    workers: [],
    settings: DEFAULT_SETTINGS,
  }));

  const [auth, setAuth] = useState({ isAdmin: false });
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [tab, setTab] = useState("ktx"); // ktx | stats | workers | settings

  const [q, setQ] = useState("");
  const [floorId, setFloorId] = useState(() => state.floors?.[0]?.id || "");

  const [deletePassModal, setDeletePassModal] = useState({
    open: false,
    title: "",
    message: "",
    onDelete: null,
  });
  const [deletePass, setDeletePass] = useState("");
  // ---------------------------
  // Settings persistence (Supabase)
  // Table: app_settings (id=1, data=jsonb)
  // ---------------------------

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      setAuth({ isAdmin: !!data.session });
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setAuth({ isAdmin: !!session });
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    (async () => {
      const nextSettings = await loadSettingsFromDb(DEFAULT_SETTINGS);
      setState((s) => ({ ...s, settings: nextSettings }));
    })();
  }, []);

  const [initModal, setInitModal] = useState({
    open: false,
    floors: 3,
    roomsPerFloor: 7,
    startNo: 101,
  });

  // dialogs
  const [roomModal, setRoomModal] = useState({
    open: false,
    floorId: null,
    roomId: null,
  });
  const [workerModal, setWorkerModal] = useState({
    open: false,
    workerId: null,
    roomCtx: null,
  });
  const [addFloorModal, setAddFloorModal] = useState(false);
  const [addRoomModal, setAddRoomModal] = useState(false);
  const [addWorkerModal, setAddWorkerModal] = useState(false);
  const [loginModal, setLoginModal] = useState(false);
  const [settingsModal, setSettingsModal] = useState(false);

  const [importModal, setImportModal] = useState({
    open: false,
    busy: false,
    result: null, // { total, workersInserted, workersUpdated, staysInserted, skipped, errors: [] }
  });

  const importFileRef = useRef(null);
  const [confirm, setConfirm] = useState({ open: false });
  const [recruiterModal, setRecruiterModal] = useState({
    open: false,
    recruiter: null,
  });

  useEffect(() => {
    // keep selected floor valid
    if (!state.floors.some((f) => f.id === floorId)) {
      setFloorId(state.floors?.[0]?.id || "");
    }
  }, [state.floors, floorId]);

  async function initKtxFromInputs(payload) {
    try {
      const ok = await initKtxSvc(payload);
      await loadAllFromDb();
      alert("Khởi tạo KTX thành công!");
      return ok;
    } catch (e) {
      alert(e.message || String(e));
      return false;
    }
  }

  const workerById = useMemo(() => {
    const map = new Map();
    for (const w of state.workers) map.set(w.id, w);
    return map;
  }, [state.workers]);

  const floor = useMemo(
    () => state.floors.find((f) => f.id === floorId) || state.floors[0],
    [state.floors, floorId],
  );

  async function handleWipeDatabase() {
    await wipeDatabase(); // gọi service
    await loadAllFromDb(); // refresh UI
  }

  const globalMatches = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return { workerIds: new Set(), roomIds: new Set() };

    const matchedWorkers = state.workers
      .filter((w) => w.fullName.toLowerCase().includes(query))
      .map((w) => w.id);

    const workerIdSet = new Set(matchedWorkers);

    const roomIdSet = new Set();
    for (const f of state.floors) {
      for (const r of f.rooms) {
        const current = r.stays.filter((s) => !s.dateOut);
        if (current.some((s) => workerIdSet.has(s.workerId)))
          roomIdSet.add(r.id);
      }
    }

    return { workerIds: workerIdSet, roomIds: roomIdSet };
  }, [q, state.workers, state.floors]);

  async function loadAllFromDb() {
    const { floors, workers } = await loadAllFromDbSvc();
    setState((s) => ({ ...s, floors, workers }));
    if (!floorId && floors[0]?.id) setFloorId(floors[0].id);
  }
  async function importExcelFile(file) {
    if (!file) return;
    if (!auth.isAdmin) return setLoginModal(true);

    setImportModal((m) => ({ ...m, busy: true, result: null }));
    try {
      const result = await importExcelFileToDb(file);
      setImportModal((m) => ({ ...m, busy: false, result }));
      await loadAllFromDb();
      alert("Nhập Excel thành công!");
      setImportModal((m) => ({ ...m, open: false }));
      setSettingsModal(false);
      setTab("ktx");
    } catch (e) {
      setImportModal((m) => ({ ...m, busy: false }));
      alert("Nhập Excel lỗi: " + (e?.message || String(e)));
    }
  }

  // ---------------------------
  // Mutations
  // ---------------------------
  function requireAdmin(action) {
    if (!auth.isAdmin) {
      setLoginModal(true);
      return;
    }
    // allow async actions too
    action();
  }

  async function addFloor(name) {
    try {
      const floorName =
        (name || "").trim() || `Tầng ${state.floors.length + 1}`;
      const sort = state.floors.length + 1;
      const id = await addFloorSvc({ name: floorName, sort });
      await loadAllFromDb();
      setFloorId(id);
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function deleteFloor(floorId) {
    try {
      const fl = state.floors.find((f) => f.id === floorId);
      const roomIds = (fl?.rooms || []).map((r) => r.id);
      await deleteFloorSvc({ floorId, roomIds });
      await loadAllFromDb();
      setFloorId((prev) => (prev === floorId ? "" : prev));
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function addRoom(floorId, code) {
    try {
      const floor = state.floors.find((f) => f.id === floorId);
      const sort = (floor?.rooms?.length || 0) + 1;
      const roomCode = (code || "").trim() || String(sort);
      await addRoomSvc({ floorId, code: roomCode, sort });
      await loadAllFromDb();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function updateRoomCode(floorId, roomId, newCode) {
    try {
      const nextCode = (newCode || "").trim();
      if (!nextCode) return alert("Tên phòng không được để trống.");
      await updateRoomCodeSvc({ roomId, code: nextCode });
      await loadAllFromDb();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function deleteRoom(floorId, roomId) {
    try {
      await deleteRoomSvc({ roomId });
      await loadAllFromDb();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function resetDb() {
    if (!auth.isAdmin) {
      setLoginModal(true);
      return;
    }

    const ok = confirm("Reset DB? Sẽ xóa toàn bộ tầng/phòng/NLĐ/lịch sử.");
    if (!ok) return;

    // Xóa theo thứ tự an toàn
    const a = await supabase.from("stays").delete().neq("id", ""); // delete all
    if (a.error) return alert("Reset lỗi (stays): " + a.error.message);

    const b = await supabase.from("workers").delete().neq("id", "");
    if (b.error) return alert("Reset lỗi (workers): " + b.error.message);

    const c = await supabase.from("rooms").delete().neq("id", "");
    if (c.error) return alert("Reset lỗi (rooms): " + c.error.message);

    const d = await supabase.from("floors").delete().neq("id", "");
    if (d.error) return alert("Reset lỗi (floors): " + d.error.message);

    alert("Đã reset DB.");
    await loadAllFromDb();

    // đóng settings về trang chủ nếu muốn
    setSettingsModal(false); // nếu bạn có state này
    setTab("ktx");
  }

  async function addWorker(worker) {
    try {
      return await addWorkerSvc(worker);
    } catch (e) {
      alert(e.message || String(e));
      return null;
    }
  }

  async function updateWorker(workerId, patch) {
    try {
      await updateWorkerSvc(workerId, patch);
      await loadAllFromDb();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function deleteWorker(workerId) {
    try {
      await deleteWorkerSvc(workerId);
      await loadAllFromDb();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function checkInWorker({ floorId, roomId, workerId, dateIn }) {
    try {
      await checkInWorkerSvc({
        roomId,
        workerId,
        dateIn: dateIn || todayISO(),
      });
      await loadAllFromDb();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function checkOutStay({ floorId, roomId, stayId, dateOut }) {
    try {
      await checkOutStaySvc({ stayId, dateOut });
      await loadAllFromDb();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  async function transferWorker({ stayId, workerId, toRoomId, transferDate }) {
    try {
      const d = transferDate || todayISO();
      await transferWorkerSvc({ stayId, workerId, toRoomId, transferDate: d });
      await loadAllFromDb();
    } catch (e) {
      alert(e.message || String(e));
    }
  }
  // ---------------------------
  // Derived
  // ---------------------------
  const allRooms = useMemo(
    () =>
      state.floors.flatMap((f) =>
        f.rooms.map((r) => ({ floorId: f.id, floorName: f.name, ...r })),
      ),
    [state.floors],
  );

  const stats = useMemo(() => {
    const buckets = new Map();
    for (const f of state.floors) {
      for (const r of f.rooms) {
        const n = r.stays.filter((s) => !s.dateOut).length;
        buckets.set(n, (buckets.get(n) || 0) + 1);
      }
    }
    const maxN = Math.max(3, ...Array.from(buckets.keys()));
    const rows = [];
    for (let i = 0; i <= maxN; i++)
      rows.push({ occupancy: i, rooms: buckets.get(i) || 0 });
    return rows;
  }, [state.floors]);

  const recruiterStats = useMemo(() => {
    const counts = new Map();
    for (const f of state.floors) {
      for (const r of f.rooms) {
        for (const st of r.stays) {
          if (st.dateOut) continue;
          const w = workerById.get(st.workerId);
          const key = (w?.recruiter || "(Chưa có)").trim() || "(Chưa có)";
          counts.set(key, (counts.get(key) || 0) + 1);
        }
      }
    }
    return Array.from(counts.entries())
      .map(([recruiter, workers]) => ({ recruiter, workers }))
      .sort((a, b) => b.workers - a.workers);
  }, [state.floors, workerById]);

  const recruiterWorkersMap = useMemo(() => {
    // Map<recruiterName, Array<{workerId, fullName, hometown, floorName, roomCode, dateIn}>>
    const map = new Map();

    for (const f of state.floors) {
      for (const r of f.rooms) {
        for (const st of r.stays) {
          if (st.dateOut) continue; // chỉ NLĐ đang ở
          const w = workerById.get(st.workerId);
          if (!w) continue;

          const recruiter = (w.recruiter || "(Chưa có)").trim() || "(Chưa có)";
          const item = {
            workerId: w.id,
            fullName: w.fullName,
            hometown: w.hometown,
            recruiter,
            floorName: f.name,
            roomCode: r.code,
            dateIn: st.dateIn,
          };

          if (!map.has(recruiter)) map.set(recruiter, []);
          map.get(recruiter).push(item);
        }
      }
    }

    // sort mỗi nhóm theo tên
    for (const [k, arr] of map.entries()) {
      arr.sort((a, b) => a.fullName.localeCompare(b.fullName, "vi"));
    }

    return map;
  }, [state.floors, workerById]);

  const totalRooms = useMemo(
    () => state.floors.reduce((sum, f) => sum + f.rooms.length, 0),
    [state.floors],
  );
  const totalCurrentWorkers = useMemo(() => {
    let n = 0;
    for (const f of state.floors)
      for (const r of f.rooms) n += r.stays.filter((s) => !s.dateOut).length;
    return n;
  }, [state.floors]);

  // ---------------------------
  // Export Excel
  // ---------------------------
  function exportExcel() {
    exportExcelSvc({
      floors: state.floors,
      workers: state.workers,
      workerById,
      stats,
      todayISO,
    });
  }
  function guardDelete({ title, message, onDelete }) {
    if (!auth.isAdmin) return setLoginModal(true);

    if (!state.settings.canDeleteStructure) {
      alert("Chức năng xóa tầng/phòng đang bị tắt trong Cài đặt.");
      return;
    }

    // nếu không bắt password thì đi thẳng Confirm như cũ
    if (!state.settings.requirePasswordOnDelete) {
      setConfirm({
        open: true,
        title,
        message,
        confirmText: "Xóa",
        onConfirm: async () => {
          await onDelete();
          setConfirm({ open: false });
        },
      });
      return;
    }

    // nếu bắt password: mở modal nhập mật khẩu
    setDeletePassModal({
      open: true,
      title,
      message,
      onDelete,
    });
  }

  // ---------------------------
  // Views
  // ---------------------------
  const Header = (
    <div className="sticky top-0 z-40 bg-gradient-to-b from-white to-white/80 backdrop-blur">
      <div className="mx-auto w-full max-w-md px-4 pt-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs font-medium text-slate-500">
              {state.settings.siteName}
            </div>
            <div className="mt-0.5 flex items-center gap-2">
              <div className="text-lg font-semibold text-slate-900">
                {tab === "ktx"
                  ? "Sơ đồ phòng"
                  : tab === "stats"
                    ? "Thống kê"
                    : tab === "workers"
                      ? "Danh sách NLĐ"
                      : "Cài đặt"}
              </div>
              {auth.isAdmin ? (
                <Pill icon={Shield} text="Admin" tone="violet" />
              ) : (
                <Pill icon={Home} text="Xem" tone="slate" />
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {tab !== "settings" ? (
              <button
                className="rounded-2xl bg-slate-900 px-3 py-2 text-xs font-semibold text-white shadow-sm"
                onClick={() => setSettingsModal(true)}
              >
                Cài đặt
              </button>
            ) : null}
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 shadow-sm">
          <Search className="h-4 w-4 text-slate-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Tìm theo tên NLĐ…"
            className="w-full bg-transparent text-sm outline-none"
          />
          {q ? (
            <button
              className="rounded-xl px-2 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              onClick={() => setQ("")}
            >
              Xóa
            </button>
          ) : null}
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2">
          <div className="rounded-3xl bg-white p-3 shadow-sm ring-1 ring-slate-100">
            <div className="flex items-center justify-between">
              <Pill
                icon={Building2}
                text={`${state.floors.length} tầng`}
                tone="sky"
              />
              <div className="text-xs text-slate-500">Tổng</div>
            </div>
            <div className="mt-2 text-2xl font-semibold text-slate-900">
              {totalRooms}
            </div>
            <div className="mt-0.5 text-xs text-slate-600">Phòng</div>
          </div>
          <div className="rounded-3xl bg-white p-3 shadow-sm ring-1 ring-slate-100">
            <div className="flex items-center justify-between">
              <Pill icon={Users} text="Đang ở" tone="green" />
              <div className="text-xs text-slate-500">Tổng</div>
            </div>
            <div className="mt-2 text-2xl font-semibold text-slate-900">
              {totalCurrentWorkers}
            </div>
            <div className="mt-0.5 text-xs text-slate-600">NLĐ</div>
          </div>
        </div>

        <div className="h-3" />
      </div>
    </div>
  );

  function RoomCard({ r, floorId }) {
    const current = r.stays.filter((s) => !s.dateOut);
    const count = current.length;
    const isMatched = q.trim() ? globalMatches.roomIds.has(r.id) : true;

    const tone =
      count === 0
        ? "bg-white"
        : count === 1
          ? "bg-emerald-50"
          : count === 2
            ? "bg-sky-50"
            : "bg-amber-50";
    const ring =
      count === 0
        ? "ring-slate-100"
        : count === 1
          ? "ring-emerald-100"
          : count === 2
            ? "ring-sky-100"
            : "ring-amber-100";

    return (
      <button
        onClick={() => setRoomModal({ open: true, floorId, roomId: r.id })}
        className={clsx(
          "relative rounded-3xl p-3 text-left shadow-sm ring-1 transition active:scale-[0.99]",
          tone,
          ring,
          isMatched ? "" : "opacity-35",
        )}
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="text-xs font-medium text-slate-500">Phòng</div>
            <div className="mt-0.5 text-base font-semibold text-slate-900">
              {r.code}
            </div>
          </div>
          <div className="grid h-9 w-9 place-items-center rounded-2xl bg-white/70 ring-1 ring-slate-200">
            {count === 0 ? (
              <DoorClosed className="h-5 w-5 text-slate-500" />
            ) : (
              <DoorOpen className="h-5 w-5 text-slate-700" />
            )}
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between">
          <Pill
            icon={Users}
            text={`${count} NLĐ`}
            tone={
              count === 0
                ? "slate"
                : count === 1
                  ? "green"
                  : count === 2
                    ? "sky"
                    : "amber"
            }
          />
          <div className="text-xs font-medium text-slate-500">
            {count === 0 ? "Trống" : "Đang ở"}
          </div>
        </div>

        {q.trim() && isMatched ? (
          <div className="mt-2 line-clamp-2 text-xs text-slate-600">
            {current
              .map((s) => workerById.get(s.workerId)?.fullName)
              .filter(Boolean)
              .join(", ")}
          </div>
        ) : null}
      </button>
    );
  }

  // ---------------------------
  // Room modal
  // ---------------------------
  const roomCtx = useMemo(() => {
    if (!roomModal.open) return null;
    const f = state.floors.find((x) => x.id === roomModal.floorId);
    const r = f?.rooms.find((x) => x.id === roomModal.roomId);
    return f && r ? { floor: f, room: r } : null;
  }, [roomModal, state.floors]);

  // ---------------------------
  // Worker modal
  // ---------------------------
  const workerCtx = useMemo(() => {
    if (!workerModal.open) return null;
    const w = workerModal.workerId
      ? workerById.get(workerModal.workerId)
      : null;

    // find current room for worker (if any)
    let currentRoom = null;
    for (const f of state.floors) {
      for (const r of f.rooms) {
        const st = r.stays.find(
          (s) => s.workerId === workerModal.workerId && !s.dateOut,
        );
        if (st) {
          currentRoom = { floor: f, room: r, stay: st };
          break;
        }
      }
      if (currentRoom) break;
    }

    return { worker: w, currentRoom };
  }, [workerModal, workerById, state.floors]);

  // ---------------------------
  // Render
  // ---------------------------
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {Header}
      {tab === "ktx" ? (
        <KtxView
          state={state}
          auth={auth}
          floorId={floorId}
          setFloorId={setFloorId}
          q={q}
          globalMatches={globalMatches}
          workerById={workerById}
          setRoomModal={setRoomModal}
          exportExcel={exportExcel}
          requireAdmin={requireAdmin}
          setInitModal={setInitModal}
          setAddRoomModal={setAddRoomModal}
          setLoginModal={setLoginModal}
          setAddFloorModal={setAddFloorModal}
          guardDelete={guardDelete}
          deleteFloor={deleteFloor}
        />
      ) : null}
      {tab === "workers" ? (
        <WorkersView
          state={state}
          q={q}
          auth={auth}
          exportExcel={exportExcel}
          requireAdmin={requireAdmin}
          setAddWorkerModal={setAddWorkerModal}
          setWorkerModal={setWorkerModal}
        />
      ) : null}
      {tab === "stats" ? (
        <StatsView
          stats={stats}
          recruiterStats={recruiterStats}
          setRecruiterModal={setRecruiterModal}
          exportExcel={exportExcel}
        />
      ) : null}
      {tab === "about" ? <AboutView about={state.settings?.about} /> : null}
      {/* bottom nav */}
      <div className="fixed inset-x-0 bottom-0 z-40">
        <div className="mx-auto w-full max-w-md px-4 pb-4">
          <div className="grid grid-cols-4 overflow-hidden rounded-3xl bg-white shadow-lg ring-1 ring-slate-200">
            <TabButton
              icon={Home}
              label="KTX"
              active={tab === "ktx"}
              onClick={() => setTab("ktx")}
            />
            <TabButton
              icon={BarChart3}
              label="Thống kê"
              active={tab === "stats"}
              onClick={() => setTab("stats")}
            />
            <TabButton
              icon={UserRound}
              label="NLĐ"
              active={tab === "workers"}
              onClick={() => setTab("workers")}
            />
            <TabButton
              icon={Users}
              label="Về chúng tôi"
              active={tab === "about"}
              onClick={() => setTab("about")}
            />
          </div>
        </div>
      </div>
      {/* Modals */}
      {/* Modals */}
      /* RoomModal - KHÔNG bọc thêm Modal */
      <RoomModal
        open={roomModal.open}
        onClose={() => setRoomModal({ open: false, floorId: "", roomId: "" })}
        roomCtx={roomCtx}
        state={state}
        auth={auth}
        q={q}
        globalMatches={globalMatches}
        workerById={workerById}
        requireAdmin={requireAdmin}
        setWorkerModal={setWorkerModal}
        setConfirm={setConfirm}
        updateRoomCode={updateRoomCode}
        deleteRoom={deleteRoom}
        checkOutStay={checkOutStay}
        transferWorker={transferWorker}
        guardDelete={guardDelete}
      />
      /* WorkerModal - KHÔNG bọc thêm Modal */
      <WorkerModal
        open={workerModal.open}
        onClose={() =>
          setWorkerModal({ open: false, workerId: null, roomCtx: null })
        }
        workerModal={workerModal}
        state={state}
        workerById={workerById}
        auth={auth}
        requireAdmin={requireAdmin}
        setConfirm={setConfirm}
        setWorkerModal={setWorkerModal}
        addWorker={addWorker}
        updateWorker={updateWorker}
        deleteWorker={deleteWorker}
        checkInWorker={checkInWorker}
      />
      /* Init KTX - chỉ dùng component tách file (xóa modal inline cũ) */
      <InitKtxModal
        initModal={initModal}
        setInitModal={setInitModal}
        requireAdmin={requireAdmin}
        initKtxFromInputs={initKtxFromInputs}
      />
      /* Add/Import modals */
      <AddFloorModal
        open={addFloorModal}
        onClose={() => setAddFloorModal(false)}
        requireAdmin={requireAdmin}
        addFloor={addFloor}
      />
      <AddRoomModal
        open={addRoomModal}
        onClose={() => setAddRoomModal(false)}
        requireAdmin={requireAdmin}
        state={state}
        floor={floor}
        setFloorId={setFloorId}
        addRoom={addRoom}
      />
      <AddWorkerModal
        open={addWorkerModal}
        onClose={() => setAddWorkerModal(false)}
        requireAdmin={requireAdmin}
        addWorker={addWorker}
      />
      <ImportExcelModal
        importModal={importModal}
        setImportModal={setImportModal}
        importFileRef={importFileRef}
        importExcelFile={importExcelFile}
      />
      <RecruiterModal
        recruiterModal={recruiterModal}
        setRecruiterModal={setRecruiterModal}
        recruiterWorkersMap={recruiterWorkersMap}
        setWorkerModal={setWorkerModal}
      />
      <LoginModal
        open={loginModal}
        onClose={() => setLoginModal(false)}
        loginEmail={loginEmail}
        setLoginEmail={setLoginEmail}
        loginPassword={loginPassword}
        setLoginPassword={setLoginPassword}
        authIsAdmin={auth.isAdmin}
      />
      <SettingsModal
        open={settingsModal}
        onClose={() => setSettingsModal(false)}
        state={state}
        setState={setState}
        auth={auth}
        setLoginModal={setLoginModal}
        DEFAULT_SETTINGS={DEFAULT_SETTINGS}
        saveSettingsToDb={saveSettingsToDb}
        requireAdmin={requireAdmin}
        onImportExcel={() => setImportModal((m) => ({ ...m, open: true }))}
        onResetDatabase={async () => {
          await handleWipeDatabase(); // wrapper bạn tạo ở bước 1
        }}
        onSignOut={async () => {
          await supabase.auth.signOut();
        }}
      />
      <Confirm
        open={!!confirm.open}
        title={confirm.title}
        message={confirm.message}
        confirmText={confirm.confirmText}
        onCancel={() => setConfirm({ open: false })}
        onConfirm={() => confirm.onConfirm?.()}
      />
      <DeleteGuardModal
        open={!!deletePassModal.open}
        title={deletePassModal.title}
        message={deletePassModal.message}
        password={deletePass}
        setPassword={setDeletePass}
        onClose={() => {
          setDeletePass("");
          setDeletePassModal({
            open: false,
            title: "",
            message: "",
            onDelete: null,
          });
        }}
        onConfirm={async () => {
          if (deletePass !== state.settings.adminPassword) {
            alert("Mật khẩu không đúng.");
            return;
          }

          try {
            await deletePassModal.onDelete?.();
          } finally {
            setDeletePass("");
            setDeletePassModal({
              open: false,
              title: "",
              message: "",
              onDelete: null,
            });
          }
        }}
      />
      <div className="h-10" />
    </div>
  );
}
