import React, { useMemo, useState } from "react";
import Modal from "../../components/ui/Modal";
import TextField from "../../components/ui/TextField";
import Pill from "../../components/ui/Pill";
import Confirm from "../../components/ui/Confirm";
import clsx from "../../components/ui/clsx";
import { Users, Trash2, Save, LogOut, Plus } from "lucide-react";

export default function RoomModal({
  open,
  onClose,

  // data
  floor,
  room, // { id, code, stays:[{id, workerId, dateIn, dateOut}] }

  workerById, // Map(workerId -> worker)

  // permissions
  auth, // { isAdmin: boolean }
  requireAdmin, // (fn)=>void

  // actions (bạn nối từ App.jsx)
  actions, // { updateRoom, deleteRoom, checkOut, openCheckInPicker }
}) {
  const [editCode, setEditCode] = useState(room?.code || "");
  const [confirmDel, setConfirmDel] = useState(false);

  React.useEffect(() => {
    setEditCode(room?.code || "");
  }, [room?.id]);

  const current = useMemo(() => {
    const stays = room?.stays || [];
    return stays.filter((s) => !s.dateOut);
  }, [room]);

  const title = room ? `Phòng ${room.code}` : "Phòng";

  if (!room) {
    return (
      <Modal open={open} title="Phòng" onClose={onClose}>
        <div className="text-sm text-slate-600">Không tìm thấy phòng.</div>
      </Modal>
    );
  }

  return (
    <>
      <Modal open={open} title={title} onClose={onClose}>
        <div className="space-y-3">
          <div className="rounded-3xl bg-slate-50 p-4 ring-1 ring-slate-100">
            <div className="text-xs font-semibold text-slate-900">
              {floor?.name || "Tầng"} • ID: {room.id}
            </div>
            <div className="mt-2 flex items-center justify-between">
              <Pill
                icon={Users}
                text={`${current.length} đang ở`}
                tone={current.length ? "green" : "slate"}
              />
              <div className="text-xs text-slate-600">
                {current.length ? "Có người" : "Trống"}
              </div>
            </div>
          </div>

          {/* Edit code */}
          <div className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-100">
            <div className="text-sm font-semibold">Thông tin phòng</div>
            <div className="mt-3">
              <TextField
                label="Mã phòng"
                value={editCode}
                onChange={setEditCode}
                placeholder="Ví dụ: P101"
                disabled={!auth?.isAdmin}
              />
            </div>

            <div className="mt-3 flex gap-2">
              <button
                className={clsx(
                  "flex-1 rounded-2xl px-4 py-3 text-sm font-semibold",
                  auth?.isAdmin
                    ? "bg-slate-900 text-white"
                    : "bg-slate-100 text-slate-600",
                )}
                onClick={() =>
                  requireAdmin(async () => {
                    if (!actions?.updateRoom) {
                      alert("Chưa nối actions.updateRoom");
                      return;
                    }
                    const next = (editCode || "").trim();
                    if (!next) return alert("Mã phòng không được rỗng.");
                    await actions.updateRoom({
                      roomId: room.id,
                      patch: { code: next },
                    });
                  })
                }
              >
                <span className="inline-flex items-center justify-center gap-2">
                  <Save className="h-4 w-4" />
                  Lưu
                </span>
              </button>

              <button
                className={clsx(
                  "rounded-2xl px-4 py-3 text-sm font-semibold",
                  auth?.isAdmin
                    ? "bg-rose-600 text-white"
                    : "bg-slate-100 text-slate-600",
                )}
                onClick={() => requireAdmin(() => setConfirmDel(true))}
              >
                <span className="inline-flex items-center justify-center gap-2">
                  <Trash2 className="h-4 w-4" />
                  Xóa
                </span>
              </button>
            </div>
          </div>

          {/* Current stays */}
          <div className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-100">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold">Người đang ở</div>
                <div className="text-xs text-slate-600">
                  Checkout từng người hoặc thêm người mới
                </div>
              </div>

              <button
                className={clsx(
                  "rounded-2xl px-3 py-2 text-xs font-semibold",
                  auth?.isAdmin
                    ? "bg-slate-900 text-white"
                    : "bg-slate-100 text-slate-600",
                )}
                onClick={() =>
                  requireAdmin(() => {
                    if (!actions?.openCheckInPicker) {
                      alert("Chưa nối actions.openCheckInPicker");
                      return;
                    }
                    actions.openCheckInPicker({ roomId: room.id });
                  })
                }
              >
                <span className="inline-flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Check-in
                </span>
              </button>
            </div>

            <div className="mt-3 space-y-2">
              {current.length ? (
                current.map((s) => {
                  const w = workerById?.get(s.workerId);
                  return (
                    <div
                      key={s.id}
                      className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white px-3 py-2"
                    >
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold text-slate-900">
                          {w?.fullName || w?.name || s.workerId}
                        </div>
                        <div className="text-xs text-slate-600">
                          Vào: {s.dateIn ? String(s.dateIn).slice(0, 10) : "-"}
                        </div>
                      </div>

                      <button
                        className={clsx(
                          "rounded-2xl px-3 py-2 text-xs font-semibold",
                          auth?.isAdmin
                            ? "bg-slate-100 text-slate-700"
                            : "bg-slate-50 text-slate-400",
                        )}
                        onClick={() =>
                          requireAdmin(async () => {
                            if (!actions?.checkOut) {
                              alert("Chưa nối actions.checkOut");
                              return;
                            }
                            await actions.checkOut({ stayId: s.id });
                          })
                        }
                      >
                        <span className="inline-flex items-center gap-2">
                          <LogOut className="h-4 w-4" />
                          Checkout
                        </span>
                      </button>
                    </div>
                  );
                })
              ) : (
                <div className="rounded-2xl bg-slate-50 p-3 text-sm text-slate-600">
                  Phòng đang trống.
                </div>
              )}
            </div>
          </div>
        </div>
      </Modal>

      <Confirm
        open={confirmDel}
        title="Xóa phòng"
        message={`Bạn chắc chắn muốn xóa phòng ${room.code}?`}
        confirmText="Xóa"
        onCancel={() => setConfirmDel(false)}
        onConfirm={() =>
          requireAdmin(async () => {
            setConfirmDel(false);
            if (!actions?.deleteRoom) {
              alert("Chưa nối actions.deleteRoom");
              return;
            }
            await actions.deleteRoom({ roomId: room.id });
            onClose?.();
          })
        }
      />
    </>
  );
}
