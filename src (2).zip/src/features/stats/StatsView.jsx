import React from "react";
import { FileDown, Filter, Users, UserRound } from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  Tooltip,
  CartesianGrid,
  LabelList,
} from "recharts";

import Pill from "../../components/ui/Pill";

export default function StatsView({
  stats,
  recruiterStats,
  setRecruiterModal,
  exportExcel,
  openStaysHistory,
  pendingElectricityCount,
  pendingElectricityAmount,
  paidElectricityCount,
  paidElectricityAmount,
  openElectricityHistory, // now a function that accepts a filter string
}) {
  return (
    <div className="mx-auto w-full max-w-md px-4 pb-24">
      <div className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-100">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-sm font-semibold">
              Thống kê theo số người/phòng
            </div>
            <div className="mt-1 text-xs text-slate-600">
              Ví dụ: phòng trống, 1 người, 2 người, …
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold"
              onClick={() => openStaysHistory?.()}
            >
              Lịch sử
            </button>
            <button
              className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold"
              onClick={() => exportExcel?.()}
            >
              <span className="inline-flex items-center gap-2">
                <FileDown className="h-4 w-4" />
                Excel
              </span>
            </button>
          </div>
        </div>

        <div className="mt-4 h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stats}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="occupancy"
                tickFormatter={(value) => `${value} người`}
              />
              <Tooltip />
              <Bar dataKey="rooms" fill="#93c5fd" radius={[10, 10, 0, 0]}>
                <LabelList dataKey="rooms" position="top" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2">
          {stats.map((s) => (
            <div
              key={s.occupancy}
              className="rounded-2xl border border-slate-200 bg-white p-3"
            >
              <div className="text-xs text-slate-600">
                {s.occupancy === 0 ? "Phòng trống" : `${s.occupancy} người`}
              </div>
              <div className="mt-1 text-lg font-semibold">{s.rooms}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-100">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold">
              Thống kê NLĐ theo người tuyển (đang ở)
            </div>
            <div className="mt-1 text-xs text-slate-600">
              Đếm NLĐ hiện đang ở theo cột “Người tuyển”.
            </div>
          </div>
          <Pill
            icon={Users}
            text={`${recruiterStats.reduce((a, b) => a + b.workers, 0)} NLĐ`}
            tone="green"
          />
        </div>

        {recruiterStats.length ? (
          <div className="mt-3 space-y-2">
            {recruiterStats.map((x) => (
              <button
                key={x.recruiter}
                className="w-full flex items-center justify-between rounded-2xl border border-slate-200 bg-white px-3 py-2 text-left hover:bg-slate-50"
                onClick={() =>
                  setRecruiterModal?.({ open: true, recruiter: x.recruiter })
                }
              >
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    {x.recruiter}
                  </div>
                  <div className="text-xs text-slate-600">
                    Bấm để xem danh sách NLĐ
                  </div>
                </div>
                <Pill icon={UserRound} text={`${x.workers}`} tone="sky" />
              </button>
            ))}
          </div>
        ) : (
          <div className="mt-3 text-sm text-slate-600">Chưa có NLĐ đang ở.</div>
        )}
      </div>

      <div className="mt-4 rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-100">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold">Gợi ý lọc</div>
            <div className="mt-1 text-xs text-slate-600">
              Dùng ô tìm kiếm ở trên để lọc theo tên NLĐ (tự làm mờ phòng không
              khớp).
            </div>
          </div>
          <Pill icon={Filter} text="Tìm nhanh" tone="sky" />
        </div>
      </div>

      {/* electricity stats */}
      <div className="mt-4 rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-100">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold">
              Tiền điện tháng hiện tại
            </div>
            <div className="mt-1 text-xs text-slate-600">
              Phòng có số đầu+số sau: chờ thu; đã bấm thu: đã thu.
            </div>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div
            className="rounded-2xl border border-slate-200 bg-white p-3 cursor-pointer hover:bg-slate-50"
            onClick={() => openElectricityHistory?.("pending")}
          >
            <div className="text-xs text-slate-600">Chờ thu</div>
            <div className="mt-1 text-lg font-semibold text-slate-900">
              {pendingElectricityAmount.toLocaleString()}₫
            </div>
            <div className="mt-0.5 text-xs text-slate-500">
              {pendingElectricityCount} phòng
            </div>
          </div>
          <div
            className="rounded-2xl border border-slate-200 bg-white p-3 cursor-pointer hover:bg-slate-50"
            onClick={() => openElectricityHistory?.("paid")}
          >
            <div className="text-xs text-slate-600">Đã thu</div>
            <div className="mt-1 text-lg font-semibold text-slate-900">
              {paidElectricityAmount.toLocaleString()}₫
            </div>
            <div className="mt-0.5 text-xs text-slate-500">
              {paidElectricityCount} phòng
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
