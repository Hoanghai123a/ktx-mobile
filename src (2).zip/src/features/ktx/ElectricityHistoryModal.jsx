import React, { useMemo } from "react";
import Modal from "../../components/ui/Modal";

export default function ElectricityHistoryModal({
  open,
  onClose,
  records = [],
  pricePerUnit = 0,
}) {
  const rows = useMemo(() => {
    return (records || []).map((r) => {
      const e = r.electricity || {};
      const start = Number(e.start_reading || 0);
      const end = Number(e.end_reading || 0);
      const used = end - start;
      const cost = used * Number(pricePerUnit || 0);

      return {
        ...r,
        month: e.month || "",
        start,
        end,
        paid: !!e.paid,
        paidAt: e.paid_at || null,
        used,
        cost,
      };
    });
  }, [records, pricePerUnit]);
  return (
    <Modal open={open} title="Lịch sử tiền điện" onClose={onClose}>
      <div className="space-y-3">
        <div className="rounded-3xl bg-white p-3 shadow-sm ring-1 ring-slate-100">
          <div className="text-sm font-semibold">Tổng: {rows.length}</div>
        </div>

        <div className="space-y-2">
          {rows.length ? (
            rows.map((r, idx) => (
              <div
                key={idx}
                className="rounded-2xl bg-white p-3 shadow-sm ring-1 ring-slate-100"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-semibold">
                      Phòng {r.roomCode}
                    </div>
                    <div className="text-xs text-slate-600">
                      Tháng {r.month}
                    </div>
                  </div>
                  <div className="text-xs text-slate-600 text-right">
                    <div>Đầu: {r.start}</div>
                    <div>Sau: {r.end}</div>
                    <div>Đã dùng: {r.used}</div>
                    <div>Số tiền: {r.cost.toLocaleString()}₫</div>
                    <div>Trạng thái: {r.paid ? "Đã thu" : "Chờ"}</div>
                    <div>
                      Thanh toán lúc:{" "}
                      {r.paid ? new Date(r.paid).toLocaleString("vi-VN") : "--"}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="rounded-2xl bg-white p-3 text-sm ring-1 ring-slate-100">
              Chưa có lịch sử.
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}
